export default function Loading() {
  return <div className="p-6 opacity-70">Loading…</div>
}
