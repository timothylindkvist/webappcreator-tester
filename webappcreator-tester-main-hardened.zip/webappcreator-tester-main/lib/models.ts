export const MODEL =
  process.env.OPENAI_MODEL ||
  process.env.NEXT_PUBLIC_AI_MODEL ||
  'gpt-5-mini';
