# Chat API removed

This legacy endpoint depended on the `ai` package.
Use `/api/build` (POST) for site generation.
